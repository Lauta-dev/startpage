'use client';

import React, { useEffect, useState, useRef } from 'react';
import { IconChevronDown, IconCheck } from '@tabler/icons-react';

const ACCENTS = [
  { label: 'Ayu Orange',   value: '#ffb454' },
  { label: 'Ayu Keyword',  value: '#ff8f40' },
  { label: 'Ayu Blue',     value: '#73b8ff' },
  { label: 'Ayu Green',    value: '#aad94c' },
  { label: 'Ayu Lavender', value: '#d2a6ff' },
  { label: 'Ayu Red',      value: '#f07178' },
  { label: 'Ayu Teal',     value: '#95e6cb' },
  { label: 'Ayu Yellow',   value: '#e6b673' },
];

const STORAGE_KEY = 'ayu-accent';
const DEFAULT = ACCENTS[0].value;

function getLuminance(hex: string): number {
  const r = parseInt(hex.slice(1, 3), 16) / 255;
  const g = parseInt(hex.slice(3, 5), 16) / 255;
  const b = parseInt(hex.slice(5, 7), 16) / 255;
  const toLinear = (c: number) => c <= 0.03928 ? c / 12.92 : Math.pow((c + 0.055) / 1.055, 2.4);
  return 0.2126 * toLinear(r) + 0.7152 * toLinear(g) + 0.0722 * toLinear(b);
}

function getContrastText(hex: string): string {
  const lum = getLuminance(hex);
  const contrastDark  = (lum + 0.05) / (getLuminance('#0d1017') + 0.05);
  const contrastLight = (getLuminance('#fafafa') + 0.05) / (lum + 0.05);
  return contrastLight >= contrastDark ? '#fafafa' : '#0d1017';
}

const AccentPicker: React.FC = () => {
  // Siempre inicia con el default en SSR y cliente por igual → sin hydration mismatch.
  // El useEffect sincroniza el valor real desde localStorage inmediatamente al montar.
  const [accent, setAccent] = useState<string>(DEFAULT);
  const [open, setOpen] = useState(false);
  const ref = useRef<HTMLDivElement>(null);

  useEffect(() => {
    // Corre solo en cliente, después de hidratación → seguro
    const saved = localStorage.getItem(STORAGE_KEY) ?? DEFAULT;
    setAccent(saved);
    // No necesitamos llamar applyAccent aquí porque el blocking script
    // en <head> ya seteó --accent antes del primer paint
  }, []);

  useEffect(() => {
    function handleClickOutside(e: MouseEvent) {
      if (ref.current && !ref.current.contains(e.target as Node)) {
        setOpen(false);
      }
    }
    document.addEventListener('mousedown', handleClickOutside);
    return () => document.removeEventListener('mousedown', handleClickOutside);
  }, []);

  function applyAccent(value: string) {
    document.documentElement.style.setProperty('--accent', value);
    document.documentElement.style.setProperty('--accent-text', getContrastText(value));
  }

  function handleSelect(value: string) {
    setAccent(value);
    applyAccent(value);
    localStorage.setItem(STORAGE_KEY, value);
    setOpen(false);
  }

  const current = ACCENTS.find(a => a.value === accent) ?? ACCENTS[0];

  return (
    <div ref={ref} className="relative">
      <button
        onClick={() => setOpen(o => !o)}
        className="flex items-center gap-2 cursor-pointer"
        style={{
          padding: '5px 10px',
          background: 'var(--bg-surface)',
          border: '1px solid var(--border)',
          borderRadius: '2px',
          color: 'var(--text-mid)',
          fontFamily: 'inherit',
          fontSize: '0.65rem',
          letterSpacing: '0.06em',
          transition: 'border-color 0.15s, color 0.15s',
        }}
        onMouseEnter={e => {
          (e.currentTarget as HTMLElement).style.borderColor = 'var(--accent)';
          (e.currentTarget as HTMLElement).style.color = 'var(--text-hi)';
        }}
        onMouseLeave={e => {
          (e.currentTarget as HTMLElement).style.borderColor = 'var(--border)';
          (e.currentTarget as HTMLElement).style.color = 'var(--text-mid)';
        }}
      >
        {/*
          El swatch usa var(--accent) directamente desde CSS.
          El blocking script en <head> ya seteó --accent antes del primer paint,
          así que este span siempre muestra el color correcto sin esperar React.
          suppressHydrationWarning porque el style inline puede diferir entre
          SSR (--accent default) y cliente (--accent del blocking script).
        */}
        <span
          className="w-4 h-4 rounded-sm shrink-0"
          style={{ background: 'var(--accent)' }}
          suppressHydrationWarning
        />
        <span className="hidden sm:inline" suppressHydrationWarning>
          {current.label}
        </span>
        <IconChevronDown
          size={18}
          stroke={2}
          className="transition-transform duration-200"
          style={{ transform: open ? 'rotate(180deg)' : 'rotate(0deg)' }}
        />
      </button>

      {open && (
        <div
          className="absolute right-0 mt-2 w-48 overflow-hidden z-50 max-h-[70vh] overflow-y-auto"
          style={{
            background: 'var(--bg-surface)',
            border: '1px solid var(--border)',
            borderRadius: '2px',
          }}
        >
          {ACCENTS.map(a => (
            <button
              key={a.value}
              onClick={() => handleSelect(a.value)}
              className="w-full flex items-center gap-3 px-3 py-2.5 text-sm transition-colors duration-150 cursor-pointer"
              style={{ color: 'var(--text-secondary)' }}
              onMouseEnter={e => {
                (e.currentTarget as HTMLElement).style.background = 'var(--bg-overlay)';
                (e.currentTarget as HTMLElement).style.color = 'var(--text-primary)';
              }}
              onMouseLeave={e => {
                (e.currentTarget as HTMLElement).style.background = 'transparent';
                (e.currentTarget as HTMLElement).style.color = 'var(--text-secondary)';
              }}
            >
              <span className="w-5 h-5 rounded-sm flex-shrink-0" style={{ background: a.value }} />
              <span className="flex-1 text-left">{a.label}</span>
              {a.value === accent && (
                <IconCheck size={18} stroke={2.5} style={{ color: 'var(--accent)' }} />
              )}
            </button>
          ))}
        </div>
      )}
    </div>
  );
};

export default AccentPicker;