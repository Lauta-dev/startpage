'use client'

import { useState } from "react";
import { IconSettings, IconPlus, IconTrash, IconX } from "@tabler/icons-react";
import AddQuickLink from "@/actions/addQuickLink";
import RemoveQuickLink from "@/actions/DeleteQuickLink";

interface QuickLink {
  id: number; name: string; url: string;
  icon: string | null; position: number; created_at: string;
}

const mono: React.CSSProperties = { fontFamily: "'IBM Plex Mono', monospace" };

function QuickLinksModal({ quickLinks }: { quickLinks: QuickLink[] }) {
  const [openModal, setOpenModal] = useState(false);
  const [urlValue, setUrlValue] = useState('');

  async function handleSubmit(e: React.FormEvent<HTMLFormElement>) {
    e.preventDefault();
    const formData = new FormData(e.currentTarget);
    await AddQuickLink({ url: formData.get('url') as string });
    setUrlValue('');
    (e.target as HTMLFormElement).reset();
  }

  return (
    <>
      <button
        onClick={() => setOpenModal(true)}
        style={{ ...mono, background: 'transparent', border: 'none', cursor: 'pointer',
          color: 'var(--text-muted)', display: 'flex', alignItems: 'center',
          padding: '3px', transition: 'color 0.15s' }}
        onMouseEnter={e => (e.currentTarget.style.color = 'var(--accent)')}
        onMouseLeave={e => (e.currentTarget.style.color = 'var(--text-muted)')}
      >
        <IconSettings size={15} stroke={1.5} />
      </button>

      <dialog open={openModal} className="modal">
        <div style={{
          background: 'var(--bg-elevated)',
          border: '1px solid var(--border)',
          borderRadius: '3px',
          width: '90%', maxWidth: '480px',
          overflow: 'hidden',
        }}
          onClick={e => e.stopPropagation()}
        >
          {/* Header */}
          <div style={{
            display: 'flex', alignItems: 'center', justifyContent: 'space-between',
            padding: '10px 16px',
            borderBottom: '1px solid var(--border-dim)',
            background: 'var(--bg-base)',
          }}>
            <span style={{ ...mono, fontSize: '0.6rem', letterSpacing: '0.14em',
              textTransform: 'uppercase', color: 'var(--text-muted)',
              display: 'flex', alignItems: 'center', gap: '8px' }}>
              <span style={{ color: 'var(--accent)' }}>●</span>
              Quick Links
            </span>
            <button onClick={() => { setOpenModal(false); setUrlValue(''); }}
              style={{ ...mono, background: 'transparent', border: '1px solid var(--border-dim)',
                borderRadius: '2px', cursor: 'pointer', color: 'var(--text-muted)',
                width: '22px', height: '22px', display: 'flex', alignItems: 'center', justifyContent: 'center',
                fontSize: '0.7rem', transition: 'all 0.15s' }}
              onMouseEnter={e => { (e.currentTarget as HTMLElement).style.borderColor = 'var(--accent)'; (e.currentTarget as HTMLElement).style.color = 'var(--accent)'; }}
              onMouseLeave={e => { (e.currentTarget as HTMLElement).style.borderColor = 'var(--border-dim)'; (e.currentTarget as HTMLElement).style.color = 'var(--text-muted)'; }}
            >
              <IconX size={12} />
            </button>
          </div>

          <div style={{ padding: '20px 18px', display: 'flex', flexDirection: 'column', gap: '20px' }}>
            {/* Add */}
            <div>
              <div style={{ ...mono, fontSize: '0.58rem', letterSpacing: '0.14em', textTransform: 'uppercase',
                color: 'var(--text-muted)', marginBottom: '10px', display: 'flex', alignItems: 'center', gap: '6px' }}>
                <span style={{ color: 'var(--accent)' }}>›</span> añadir enlace
              </div>
              <form onSubmit={handleSubmit} style={{ display: 'flex', border: '1px solid var(--border)', borderRadius: '2px', overflow: 'hidden' }}
                onFocus={e => (e.currentTarget.style.borderColor = 'var(--accent)')}
                onBlur={e => (e.currentTarget.style.borderColor = 'var(--border)')}
              >
                <input type="url" name="url" value={urlValue}
                  onChange={e => setUrlValue(e.target.value)}
                  placeholder="https://ejemplo.com"
                  style={{ ...mono, flex: 1, background: 'var(--bg-surface)', border: 'none',
                    outline: 'none', fontSize: '0.75rem', color: 'var(--text-primary)',
                    padding: '9px 12px' }}
                />
                <button type="submit" disabled={!urlValue.trim()}
                  style={{ ...mono, background: 'var(--accent)', border: 'none',
                    borderLeft: '1px solid rgba(0,0,0,0.2)', padding: '9px 14px',
                    fontSize: '0.62rem', fontWeight: 700, letterSpacing: '0.1em',
                    textTransform: 'uppercase', color: 'var(--bg-base)', cursor: urlValue.trim() ? 'pointer' : 'not-allowed',
                    opacity: urlValue.trim() ? 1 : 0.35, display: 'flex', alignItems: 'center', gap: '5px',
                    flexShrink: 0, transition: 'filter 0.15s' }}
                  onMouseEnter={e => { if (urlValue.trim()) (e.currentTarget as HTMLElement).style.filter = 'brightness(1.1)'; }}
                  onMouseLeave={e => { (e.currentTarget as HTMLElement).style.filter = 'brightness(1)'; }}
                >
                  <IconPlus size={13} /> Añadir
                </button>
              </form>
            </div>

            {/* Delete list */}
            {quickLinks.length > 0 && (
              <div>
                <div style={{ ...mono, fontSize: '0.58rem', letterSpacing: '0.14em', textTransform: 'uppercase',
                  color: 'var(--text-muted)', marginBottom: '10px', display: 'flex', alignItems: 'center', gap: '6px' }}>
                  <span style={{ color: 'var(--color-danger)' }}>›</span> eliminar enlace
                </div>
                <div style={{ display: 'flex', flexDirection: 'column', gap: '2px' }}>
                  {quickLinks.map(link => (
                    <button key={link.id} onClick={() => RemoveQuickLink(link.id)}
                      style={{ ...mono, display: 'flex', alignItems: 'center', gap: '10px',
                        padding: '8px 10px', border: '1px solid var(--border-dim)', borderRadius: '2px',
                        background: 'var(--bg-surface)', cursor: 'pointer', textAlign: 'left',
                        width: '100%', transition: 'all 0.12s' }}
                      onMouseEnter={e => {
                        const el = e.currentTarget as HTMLElement;
                        el.style.borderColor = 'var(--color-danger-border)';
                        el.style.background = 'var(--color-danger-bg)';
                        const del = el.querySelector('.del-icon') as HTMLElement;
                        if (del) del.style.opacity = '1';
                        const name = el.querySelector('.link-name') as HTMLElement;
                        if (name) name.style.color = 'var(--color-danger)';
                      }}
                      onMouseLeave={e => {
                        const el = e.currentTarget as HTMLElement;
                        el.style.borderColor = 'var(--border-dim)';
                        el.style.background = 'var(--bg-surface)';
                        const del = el.querySelector('.del-icon') as HTMLElement;
                        if (del) del.style.opacity = '0';
                        const name = el.querySelector('.link-name') as HTMLElement;
                        if (name) name.style.color = 'var(--text-secondary)';
                      }}
                    >
                      <div style={{ width: '22px', height: '22px', borderRadius: '2px',
                        background: 'var(--bg-elevated)', border: '1px solid var(--border-dim)',
                        display: 'flex', alignItems: 'center', justifyContent: 'center', flexShrink: 0 }}>
                        {/* eslint-disable-next-line @next/next/no-img-element */}
                        <img src={link.icon ?? ''} alt={link.name} style={{ width: '12px', height: '12px', objectFit: 'contain' }} />
                      </div>
                      <span className="link-name" style={{ flex: 1, fontSize: '0.72rem',
                        color: 'var(--text-secondary)', overflow: 'hidden', textOverflow: 'ellipsis',
                        whiteSpace: 'nowrap', transition: 'color 0.12s' }}>
                        {link.name}
                      </span>
                      <span className="del-icon" style={{ opacity: 0, transition: 'opacity 0.12s', color: 'var(--color-danger)' }}>
                        <IconTrash size={13} />
                      </span>
                    </button>
                  ))}
                </div>
              </div>
            )}
          </div>
        </div>
        <div className="modal-backdrop" onClick={() => setOpenModal(false)} />
      </dialog>
    </>
  );
}

export default QuickLinksModal;
